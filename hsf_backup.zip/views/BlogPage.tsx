import React from 'react'; export default function BlogPage() { return <div className="p-8"><h1>Blog Page</h1></div>; }
