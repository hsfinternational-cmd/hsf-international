import React from 'react'; export default function MediaPage() { return <div className="p-8"><h1>Media Page</h1></div>; }
